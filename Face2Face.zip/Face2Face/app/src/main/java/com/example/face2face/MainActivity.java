package com.example.face2face;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.AdapterView;

import androidx.core.view.WindowCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.face2face.databinding.ActivityMainBinding;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {

    private ListView transformationListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        transformationListView = (ListView) findViewById(R.id.transformationListView);
        ArrayList<Transformation> items = new ArrayList<Transformation>();
        ArrayAdapter<Transformation> itemsAdapter = new ArrayAdapter<Transformation>(this,
                android.R.layout.simple_list_item_1, items);
        transformationListView.setAdapter(itemsAdapter);

        Customer customer1 = new Customer("Franck", "Marc");
        Transformation transfo1 = new Transformation("Opération des temps", customer1);
        itemsAdapter.add(transfo1);

    }
}