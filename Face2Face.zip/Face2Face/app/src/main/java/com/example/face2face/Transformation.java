package com.example.face2face;

import java.util.Date;
import java.util.UUID;

public class Transformation {
    public Date after_date;
    public Date before_date;
    public UUID id;
    public String nom;
    public Customer customer;

    public Transformation(String nom, Customer customer){
        this.before_date = new Date();
        this.after_date = new Date();
        this.id = UUID.randomUUID();
        this.nom = nom;
        this.customer = customer;
    }
}
