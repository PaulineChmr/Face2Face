package com.example.face2face;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class Customer {
    public String first_name;
    public UUID id;
    public String last_name;
    public int number_of_transformations;
    public List<Transformation> transformation_list;

    public Customer(String first_name, String last_name){
        this.first_name = first_name;
        this.id = UUID.randomUUID();
        this.last_name = last_name;
        this.number_of_transformations = 0;
        this.transformation_list = new ArrayList<Transformation>();
    }
}
